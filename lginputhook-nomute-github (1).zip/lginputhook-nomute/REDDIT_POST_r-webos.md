**Title:** Hold Volume Down on the 2025 Magic Remote without the TV muting (rooted webOS, .ipk, 2 toggles)

---

LG decided that holding Volume Down on the 2025 AI Magic Remote should **mute the TV**. Because obviously, when you want it quieter, the logical next step is *no sound at all*. And of course there is no setting for it. Thanks, LG.

So here's a small homebrew app that fixes it. Two toggles, that's it:

- **Volume Down: hold without mute**: holding it just keeps lowering the volume, like a remote should work.
- **Accessibility button works as Mute**: the top-right button on the remote (which opens the Accessibility menu, which I have never needed once) becomes a real Mute button.

**How it works:** it hooks the input service (lginput2) via ezinject and turns the auto-repeat events into plain taps, so the TV never sees a "long press". Nothing is flashed, the hook lives in RAM only. Uninstall the app + restart the TV = back to stock.

**Install:** grab the `.ipk` from the releases page and sideload it (Glasshouse, Dev Manager, ares-install, whatever you like). Then do a **full restart** (unplug it, standby isn't enough) and open the app.

**Tested on:** LG G5 (webOS 25) with the 2025 AI Magic Remote, rooted. Anything else is on you, feedback welcome.

GitHub: https://github.com/frankthecrank/lginputhook-nomute

**Credits, because this is 100% standing on other people's shoulders:**
- Simon34545's [lginputhook](https://github.com/Simon34545/lginputhook) (the app and UI)
- sundermann's [inputhookpp](https://github.com/sundermann/inputhookpp) (the native hook, GPLv3)
- Informatic's original [inputhook gist](https://gist.github.com/Informatic/319bcaf94436b9136904473ca4f4ec9c)
- smx-smx's [ezinject](https://github.com/smx-smx/ezinject) and the [openlgtv](https://github.com/openlgtv/buildroot-nc4) toolchain
- the [webosbrew](https://github.com/webosbrew) crew for the Homebrew Channel and rooting

I'm not a webOS developer. I built this together with Claude (AI), so there may be rough edges. Source and build scripts are in the repo; the build is reproducible.

Use at your own risk, not affiliated with LG. Which, honestly, is a feature.
